import * as _angular_core from '@angular/core';
import { OnInit, TemplateRef, ElementRef, ChangeDetectorRef } from '@angular/core';
import { ControlValueAccessor } from '@angular/forms';
import * as i1 from '@angular/common';

interface ConfigModel {
    align?: boolean;
    boundaryLinks: boolean;
    directionLinks: boolean;
    firstText: string;
    itemsPerPage: number;
    lastText: string;
    maxSize: number;
    nextText: string;
    pageBtnClass: string;
    previousText: string;
    rotate: boolean;
}
/**
 * Contain information about the page
 */
interface PagesModel {
    /** Text, which is displayed in the link */
    text: string;
    /** Page number */
    number: number;
    /** If `true`, then this is the current page */
    active: boolean;
}
interface PagerModel {
    itemsPerPage: number;
    previousText: string;
    nextText: string;
    pageBtnClass: string;
    align: boolean;
}
/**
 * A context for the
 * * `customPageTemplate`
 * * `customNextTemplate`
 * * `customPreviousTemplate`
 * * `customFirstTemplate`
 * * `customLastTemplate`
 * inputs for link templates in case you want to override one
 */
interface PaginationLinkContext {
    /** The currently selected page number */
    currentPage: number;
    /** If `true`, the current link is disabled */
    disabled: boolean;
}
/**
 * A context for the `pageTemplate` inputs for link template
 */
interface PaginationNumberLinkContext extends PaginationLinkContext {
    /** Contain the page information */
    $implicit: PagesModel;
}

/** Provides default values for Pagination and pager components */
declare class PaginationConfig {
    main: Partial<ConfigModel>;
    pager: PagerModel;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<PaginationConfig, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<PaginationConfig>;
}

interface PageChangedEvent {
    itemsPerPage: number;
    page: number;
}
declare class PaginationComponent implements ControlValueAccessor, OnInit {
    private elementRef;
    private changeDetection;
    config?: Partial<ConfigModel>;
    /** if `true` aligns each link to the sides of pager */
    align: _angular_core.InputSignal<boolean>;
    /** limit number for page links in pager */
    maxSize: _angular_core.InputSignal<number | undefined>;
    /** if false first and last buttons will be hidden */
    boundaryLinks: _angular_core.InputSignal<boolean>;
    /** if false previous and next buttons will be hidden */
    directionLinks: _angular_core.InputSignal<boolean>;
    /** first button text */
    firstText: _angular_core.InputSignal<string | undefined>;
    /** previous button text */
    previousText: _angular_core.InputSignal<string | undefined>;
    /** next button text */
    nextText: _angular_core.InputSignal<string | undefined>;
    /** last button text */
    lastText: _angular_core.InputSignal<string | undefined>;
    /** if true current page will in the middle of pages list */
    rotate: _angular_core.InputSignal<boolean>;
    /** add class to <code><li\></code> */
    pageBtnClass: _angular_core.InputSignal<string>;
    /** if true pagination component will be disabled */
    disabled: _angular_core.InputSignal<boolean>;
    /** custom template for page link */
    customPageTemplate: _angular_core.InputSignal<TemplateRef<PaginationNumberLinkContext> | undefined>;
    /** custom template for next link */
    customNextTemplate: _angular_core.InputSignal<TemplateRef<PaginationLinkContext> | undefined>;
    /** custom template for previous link */
    customPreviousTemplate: _angular_core.InputSignal<TemplateRef<PaginationLinkContext> | undefined>;
    /** custom template for first link */
    customFirstTemplate: _angular_core.InputSignal<TemplateRef<PaginationLinkContext> | undefined>;
    /** custom template for last link */
    customLastTemplate: _angular_core.InputSignal<TemplateRef<PaginationLinkContext> | undefined>;
    /** maximum number of items per page. If value less than 1 will display all items on one page */
    itemsPerPageInput: _angular_core.InputSignal<number>;
    /** total number of items in all pages */
    totalItemsInput: _angular_core.InputSignal<number>;
    /** fired when total pages count changes, $event:number equals to total pages count */
    numPages: _angular_core.OutputEmitterRef<number>;
    /** fired when page was changed, $event:{page, itemsPerPage} equals to object
     * with current page index and number of items per page
     */
    pageChanged: _angular_core.OutputEmitterRef<PageChangedEvent>;
    onChange: Function;
    onTouched: Function;
    classMap: string;
    pages?: PagesModel[];
    protected inited: boolean;
    constructor(elementRef: ElementRef, paginationConfig: PaginationConfig, changeDetection: ChangeDetectorRef);
    protected _itemsPerPage: number;
    get itemsPerPage(): number;
    protected _totalItems: number;
    get totalItems(): number;
    protected _totalPages: number;
    get totalPages(): number;
    set totalPages(v: number);
    protected _page: number;
    get page(): number;
    set page(value: number);
    configureOptions(config: Partial<ConfigModel>): void;
    ngOnInit(): void;
    protected _maxSize: number;
    protected _rotate: boolean;
    protected _boundaryLinks: boolean;
    protected _directionLinks: boolean;
    protected _pageBtnClass: string;
    writeValue(value: number): void;
    getText(key: string): string;
    noPrevious(): boolean;
    noNext(): boolean;
    registerOnChange(fn: () => void): void;
    registerOnTouched(fn: () => void): void;
    selectPage(page: number, event?: Event): void;
    protected makePage(num: number, text: string, active: boolean): {
        number: number;
        text: string;
        active: boolean;
    };
    protected getPages(currentPage: number, totalPages: number): PagesModel[];
    protected calculateTotalPages(): number;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<PaginationComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<PaginationComponent, "pagination", never, { "align": { "alias": "align"; "required": false; "isSignal": true; }; "maxSize": { "alias": "maxSize"; "required": false; "isSignal": true; }; "boundaryLinks": { "alias": "boundaryLinks"; "required": false; "isSignal": true; }; "directionLinks": { "alias": "directionLinks"; "required": false; "isSignal": true; }; "firstText": { "alias": "firstText"; "required": false; "isSignal": true; }; "previousText": { "alias": "previousText"; "required": false; "isSignal": true; }; "nextText": { "alias": "nextText"; "required": false; "isSignal": true; }; "lastText": { "alias": "lastText"; "required": false; "isSignal": true; }; "rotate": { "alias": "rotate"; "required": false; "isSignal": true; }; "pageBtnClass": { "alias": "pageBtnClass"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "customPageTemplate": { "alias": "customPageTemplate"; "required": false; "isSignal": true; }; "customNextTemplate": { "alias": "customNextTemplate"; "required": false; "isSignal": true; }; "customPreviousTemplate": { "alias": "customPreviousTemplate"; "required": false; "isSignal": true; }; "customFirstTemplate": { "alias": "customFirstTemplate"; "required": false; "isSignal": true; }; "customLastTemplate": { "alias": "customLastTemplate"; "required": false; "isSignal": true; }; "itemsPerPageInput": { "alias": "itemsPerPage"; "required": false; "isSignal": true; }; "totalItemsInput": { "alias": "totalItems"; "required": false; "isSignal": true; }; }, { "numPages": "numPages"; "pageChanged": "pageChanged"; }, never, never, true, never>;
}

declare class PagerComponent implements ControlValueAccessor, OnInit {
    private elementRef;
    private changeDetection;
    config?: Partial<ConfigModel>;
    /** if `true` aligns each link to the sides of pager */
    align: _angular_core.InputSignal<boolean>;
    /** limit number for page links in pager */
    maxSize: _angular_core.InputSignal<number | undefined>;
    /** if false first and last buttons will be hidden */
    boundaryLinks: _angular_core.InputSignal<boolean>;
    /** if false previous and next buttons will be hidden */
    directionLinks: _angular_core.InputSignal<boolean>;
    /** first button text */
    firstText: _angular_core.InputSignal<string>;
    /** previous button text */
    previousText: _angular_core.InputSignal<string>;
    /** next button text */
    nextText: _angular_core.InputSignal<string>;
    /** last button text */
    lastText: _angular_core.InputSignal<string>;
    /** if true current page will in the middle of pages list */
    rotate: _angular_core.InputSignal<boolean>;
    /** add class to <code><li\></code> */
    pageBtnClass: _angular_core.InputSignal<string>;
    /** if true pagination component will be disabled */
    disabled: _angular_core.InputSignal<boolean>;
    /** maximum number of items per page. If value less than 1 will display all items on one page */
    itemsPerPageInput: _angular_core.InputSignal<number>;
    /** total number of items in all pages */
    totalItemsInput: _angular_core.InputSignal<number>;
    /** fired when total pages count changes, $event:number equals to total pages count */
    numPages: _angular_core.OutputEmitterRef<number>;
    /** fired when page was changed, $event:{page, itemsPerPage} equals to
     * object with current page index and number of items per page
     */
    pageChanged: _angular_core.OutputEmitterRef<PageChangedEvent>;
    onChange: Function;
    onTouched: Function;
    classMap: string;
    pages?: PagesModel[];
    protected inited: boolean;
    constructor(elementRef: ElementRef, paginationConfig: PaginationConfig, changeDetection: ChangeDetectorRef);
    protected _itemsPerPage: number;
    get itemsPerPage(): number;
    protected _totalItems: number;
    get totalItems(): number;
    protected _totalPages: number;
    get totalPages(): number;
    set totalPages(v: number);
    protected _page: number;
    get page(): number;
    set page(value: number);
    configureOptions(config: Partial<ConfigModel>): void;
    protected _maxSize: number;
    protected _rotate: boolean;
    protected _boundaryLinks: boolean;
    protected _directionLinks: boolean;
    protected _pageBtnClass: string;
    ngOnInit(): void;
    writeValue(value: number): void;
    getText(key: string): string;
    noPrevious(): boolean;
    noNext(): boolean;
    registerOnChange(fn: () => void): void;
    registerOnTouched(fn: () => void): void;
    selectPage(page: number, event?: Event): void;
    protected makePage(num: number, text: string, active: boolean): {
        number: number;
        text: string;
        active: boolean;
    };
    protected getPages(currentPage: number, totalPages: number): PagesModel[];
    protected calculateTotalPages(): number;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<PagerComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<PagerComponent, "pager", never, { "align": { "alias": "align"; "required": false; "isSignal": true; }; "maxSize": { "alias": "maxSize"; "required": false; "isSignal": true; }; "boundaryLinks": { "alias": "boundaryLinks"; "required": false; "isSignal": true; }; "directionLinks": { "alias": "directionLinks"; "required": false; "isSignal": true; }; "firstText": { "alias": "firstText"; "required": false; "isSignal": true; }; "previousText": { "alias": "previousText"; "required": false; "isSignal": true; }; "nextText": { "alias": "nextText"; "required": false; "isSignal": true; }; "lastText": { "alias": "lastText"; "required": false; "isSignal": true; }; "rotate": { "alias": "rotate"; "required": false; "isSignal": true; }; "pageBtnClass": { "alias": "pageBtnClass"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "itemsPerPageInput": { "alias": "itemsPerPage"; "required": false; "isSignal": true; }; "totalItemsInput": { "alias": "totalItems"; "required": false; "isSignal": true; }; }, { "numPages": "numPages"; "pageChanged": "pageChanged"; }, never, never, true, never>;
}

declare class PaginationModule {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<PaginationModule, never>;
    static ɵmod: _angular_core.ɵɵNgModuleDeclaration<PaginationModule, never, [typeof i1.CommonModule, typeof PagerComponent, typeof PaginationComponent], [typeof PagerComponent, typeof PaginationComponent]>;
    static ɵinj: _angular_core.ɵɵInjectorDeclaration<PaginationModule>;
}

export { PagerComponent, PaginationComponent, PaginationConfig, PaginationModule };
export type { PageChangedEvent, PagesModel, PaginationLinkContext, PaginationNumberLinkContext };
