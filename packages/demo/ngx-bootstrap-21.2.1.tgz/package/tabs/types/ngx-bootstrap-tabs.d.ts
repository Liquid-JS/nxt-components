import * as _angular_core from '@angular/core';
import { ViewContainerRef, TemplateRef, OnDestroy, Renderer2, ElementRef, OnInit, ChangeDetectorRef } from '@angular/core';
import * as i1 from '@angular/common';

declare class NgTranscludeDirective {
    viewRef: ViewContainerRef;
    protected _ngTransclude?: TemplateRef<any>;
    ngTransclude: _angular_core.InputSignal<TemplateRef<any> | undefined>;
    constructor(viewRef: ViewContainerRef);
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<NgTranscludeDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<NgTranscludeDirective, "[ngTransclude]", never, { "ngTransclude": { "alias": "ngTransclude"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class TabsetConfig {
    /** provides default navigation context class: 'tabs' or 'pills' */
    type: string;
    /** provides possibility to set keyNavigations enable or disable, by default is enable */
    isKeysAllowed: boolean;
    /** aria label for tab list */
    ariaLabel: string;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TabsetConfig, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<TabsetConfig>;
}

declare class TabsetComponent implements OnDestroy {
    private _config;
    private renderer;
    private elementRef;
    /** if true tabs will be placed vertically */
    vertical: _angular_core.InputSignal<boolean>;
    /** if true tabs fill the container and have a consistent width */
    justified: _angular_core.InputSignal<boolean>;
    /** navigation context class: 'tabs' or 'pills' */
    type: _angular_core.InputSignal<string>;
    get isKeysAllowed(): boolean;
    set isKeysAllowed(value: boolean);
    clazz: boolean;
    tabs: TabDirective[];
    classMap: {
        [key: string]: boolean;
    };
    /** aria label for tab list */
    ariaLabel: string;
    protected isDestroyed: boolean;
    protected _isKeysAllowed: boolean;
    private defaultActivationScheduled;
    constructor(_config: TabsetConfig, renderer: Renderer2, elementRef: ElementRef);
    ngOnDestroy(): void;
    addTab(tab: TabDirective): void;
    private insertTabByOrder;
    removeTab(tab: TabDirective, options?: {
        reselect: boolean;
        emit: boolean;
    }): void;
    keyNavActions(event: KeyboardEvent, index: number): void;
    protected getClosestTabIndex(index: number): number;
    protected hasAvailableTabs(index: number): boolean;
    protected setClassMap(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TabsetComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<TabsetComponent, "tabset", never, { "vertical": { "alias": "vertical"; "required": false; "isSignal": true; }; "justified": { "alias": "justified"; "required": false; "isSignal": true; }; "type": { "alias": "type"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

declare class TabDirective implements OnInit, OnDestroy {
    elementRef: ElementRef;
    renderer: Renderer2;
    private _cdr;
    /** tab header text */
    heading: _angular_core.InputSignal<string | undefined>;
    /** tab id. The same id with suffix '-link' will be added to the corresponding &lt;li&gt; element  */
    id?: string;
    idInput: _angular_core.InputSignal<string | undefined>;
    /** if true tab can not be activated */
    disabled: boolean;
    disabledInput: _angular_core.InputSignal<boolean>;
    /** if true tab can be removable, additional button will appear */
    removable: boolean;
    removableInput: _angular_core.InputSignal<boolean>;
    /** tab order for sorting when using dynamic tabs with *ngIf */
    tabOrder?: number;
    tabOrderInput: _angular_core.InputSignal<number | undefined>;
    /** if set, will be added to the tab's class attribute. Multiple classes are supported. */
    customClassInput: _angular_core.InputSignal<string | undefined>;
    /** tab active state - can be set via input */
    activeInput: _angular_core.InputSignal<boolean | undefined>;
    /** tab active state toggle */
    get active(): boolean | undefined;
    set active(active: boolean | undefined);
    /** fired when tab became active, $event:Tab equals to selected instance of Tab component */
    selectTab: _angular_core.OutputEmitterRef<TabDirective>;
    /** fired when tab became inactive, $event:Tab equals to deselected instance of Tab component */
    deselect: _angular_core.OutputEmitterRef<TabDirective>;
    /** fired before tab will be removed, $event:Tab equals to instance of removed tab */
    removed: _angular_core.OutputEmitterRef<TabDirective>;
    addClass: boolean;
    role: string;
    get ariaLabelledby(): string;
    headingRef?: TemplateRef<any>;
    tabset: TabsetComponent;
    protected _active?: boolean | undefined;
    _customClass: string;
    constructor(tabset: TabsetComponent, elementRef: ElementRef, renderer: Renderer2, _cdr: ChangeDetectorRef);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TabDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<TabDirective, "tab, [tab]", ["tab"], { "heading": { "alias": "heading"; "required": false; "isSignal": true; }; "idInput": { "alias": "id"; "required": false; "isSignal": true; }; "disabledInput": { "alias": "disabled"; "required": false; "isSignal": true; }; "removableInput": { "alias": "removable"; "required": false; "isSignal": true; }; "tabOrderInput": { "alias": "tabOrder"; "required": false; "isSignal": true; }; "customClassInput": { "alias": "customClass"; "required": false; "isSignal": true; }; "activeInput": { "alias": "active"; "required": false; "isSignal": true; }; }, { "selectTab": "selectTab"; "deselect": "deselect"; "removed": "removed"; }, never, never, true, never>;
}

/** Should be used to mark <ng-template> element as a template for tab heading */
declare class TabHeadingDirective {
    templateRef?: TemplateRef<any>;
    constructor(templateRef: TemplateRef<any>, tab: TabDirective);
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TabHeadingDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<TabHeadingDirective, "[tabHeading]", never, {}, {}, never, never, true, never>;
}

declare class TabsModule {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TabsModule, never>;
    static ɵmod: _angular_core.ɵɵNgModuleDeclaration<TabsModule, never, [typeof i1.CommonModule, typeof NgTranscludeDirective, typeof TabDirective, typeof TabsetComponent, typeof TabHeadingDirective], [typeof TabDirective, typeof TabsetComponent, typeof TabHeadingDirective, typeof NgTranscludeDirective]>;
    static ɵinj: _angular_core.ɵɵInjectorDeclaration<TabsModule>;
}

export { NgTranscludeDirective, TabDirective, TabHeadingDirective, TabsModule, TabsetComponent, TabsetConfig };
