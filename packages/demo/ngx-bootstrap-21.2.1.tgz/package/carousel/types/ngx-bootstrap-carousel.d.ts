import * as _angular_core from '@angular/core';
import { OnInit, OnDestroy, AfterViewInit, ChangeDetectorRef } from '@angular/core';
import { LinkedList, IBsVersion } from 'ngx-bootstrap/utils';

declare class SlideComponent implements OnInit, OnDestroy {
    /** Is current slide active */
    active: boolean;
    activeInput: _angular_core.InputSignal<boolean | undefined>;
    itemWidth: string;
    order: number;
    isAnimated: boolean;
    /** Wraps element by appropriate CSS classes */
    addClass: boolean;
    /** Link to Parent(container-collection) component */
    protected carousel: CarouselComponent;
    multilist: boolean;
    constructor(carousel: CarouselComponent);
    /** Fires changes in container collection after adding a new slide instance */
    ngOnInit(): void;
    /** Fires changes in container collection after removing of this slide instance */
    ngOnDestroy(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SlideComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SlideComponent, "slide", never, { "activeInput": { "alias": "active"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

declare class CarouselConfig {
    interval: number;
    noPause: boolean;
    noWrap: boolean;
    showIndicators: boolean;
    pauseOnFocus: boolean;
    indicatorsByChunk: boolean;
    itemsPerSlide: number;
    singleSlideOffset: boolean;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CarouselConfig, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<CarouselConfig>;
}

interface SlideWithIndex {
    item: SlideComponent;
    index: number;
}

declare enum Direction {
    UNKNOWN = 0,
    NEXT = 1,
    PREV = 2
}
/**
 * Base element to create carousel
 */
declare class CarouselComponent implements AfterViewInit, OnDestroy {
    private _config;
    private cdr;
    platformId: number;
    noWrap: _angular_core.InputSignal<boolean>;
    noPause: _angular_core.InputSignal<boolean>;
    showIndicators: _angular_core.InputSignal<boolean>;
    pauseOnFocus: _angular_core.InputSignal<boolean>;
    indicatorsByChunk: _angular_core.InputSignal<boolean>;
    itemsPerSlide: _angular_core.InputSignal<number>;
    singleSlideOffset: _angular_core.InputSignal<boolean>;
    /** Turn on/off animation. Animation doesn't work for multilist carousel */
    isAnimated: _angular_core.InputSignal<boolean>;
    /** Will be emitted when active slide has been changed. Part of two-way-bindable [(activeSlide)] property */
    activeSlideChange: _angular_core.OutputEmitterRef<number>;
    /** Will be emitted when active slides has been changed in multilist mode */
    slideRangeChange: _angular_core.OutputEmitterRef<void | number[]>;
    /** Index of currently displayed slide(started for 0) */
    activeSlideInput: _angular_core.InputSignal<number>;
    startFromIndex: _angular_core.InputSignal<number>;
    /**
     * Delay of item cycling in milliseconds. If false, carousel won't cycle
     * automatically.
     */
    interval: _angular_core.InputSignal<number>;
    get slides(): SlideComponent[];
    get isFirstSlideVisible(): boolean;
    get isLastSlideVisible(): boolean;
    get activeSlide(): number;
    set activeSlide(index: number);
    protected currentInterval?: number;
    protected _currentActiveSlide?: number;
    protected _slides: LinkedList<SlideComponent>;
    protected _chunkedSlides?: SlideWithIndex[][];
    protected _slidesWithIndexes?: SlideWithIndex[];
    protected _currentVisibleSlidesIndex: number;
    protected isPlaying: boolean;
    protected destroyed: boolean;
    private customActiveSlide?;
    private _indicatorsByChunk;
    currentId: number;
    get _bsVer(): IBsVersion;
    constructor(_config: CarouselConfig, cdr: ChangeDetectorRef, platformId: number);
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    /**
     * Adds new slide. If this slide is first in collection - set it as active
     * and starts auto changing
     * @param slide
     */
    addSlide(slide: SlideComponent): void;
    /**
     * Removes specified slide. If this slide is active - will roll to another
     * slide
     * @param slide
     */
    removeSlide(slide: SlideComponent): void;
    nextSlideFromInterval(force?: boolean): void;
    /**
     * Rolling to next slide
     * @param force: {boolean} if true - will ignore noWrap flag
     */
    nextSlide(force?: boolean): void;
    /**
     * Rolling to previous slide
     * @param force: {boolean} if true - will ignore noWrap flag
     */
    previousSlide(force?: boolean): void;
    getFirstVisibleIndex(): number;
    getLastVisibleIndex(): number;
    getActive: (slide: SlideComponent) => boolean;
    move(direction: Direction, force?: boolean): void;
    /**
     * Swith slides by enter, space and arrows keys
     * @internal
     */
    keydownPress(event: KeyboardEvent): void;
    /**
     * Play on mouse leave
     * @internal
     */
    onMouseLeave(): void;
    /**
     * Play on mouse up
     * @internal
     */
    onMouseUp(): void;
    /**
     * When slides on focus autoplay is stopped(optional)
     * @internal
     */
    pauseFocusIn(): void;
    /**
     * When slides out of focus autoplay is started
     * @internal
     */
    pauseFocusOut(): void;
    /**
     * Rolling to specified slide
     * @param index: {number} index of slide, which must be shown
     */
    selectSlide(index: number): void;
    /**
     * Starts a auto changing of slides
     */
    play(): void;
    /**
     * Stops a auto changing of slides
     */
    pause(): void;
    /**
     * Finds and returns index of currently displayed slide
     */
    getCurrentSlideIndex(): number;
    /**
     * Defines, whether the specified index is last in collection
     * @param index
     */
    isLast(index: number): boolean;
    /**
     * Defines, whether the specified index is first in collection
     * @param index
     */
    isFirst(index: number): boolean;
    indicatorsSlides(): SlideComponent[];
    private selectInitialSlides;
    /**
     * Defines next slide index, depending of direction
     * @param direction: Direction(UNKNOWN|PREV|NEXT)
     * @param force: {boolean} if TRUE - will ignore noWrap flag, else will
     *   return undefined if next slide require wrapping
     */
    private findNextSlideIndex;
    private mapSlidesAndIndexes;
    private selectSlideRange;
    private selectRangeByNestedIndex;
    private isIndexOnTheEdges;
    private isIndexInRange;
    private hideSlides;
    private isVisibleSlideListLast;
    private isVisibleSlideListFirst;
    private moveSliderByOneItem;
    private makeSlidesConsistent;
    private moveMultilist;
    private getVisibleIndexes;
    /**
     * Sets a slide, which specified through index, as active
     * @param index
     */
    private _select;
    /**
     * Starts loop of auto changing of slides - zoneless version
     */
    private restartTimer;
    get multilist(): boolean;
    /**
     * Stops loop of auto changing of slides
     */
    private resetTimer;
    checkDisabledClass(buttonType: 'prev' | 'next'): boolean;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CarouselComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<CarouselComponent, "carousel", never, { "noWrap": { "alias": "noWrap"; "required": false; "isSignal": true; }; "noPause": { "alias": "noPause"; "required": false; "isSignal": true; }; "showIndicators": { "alias": "showIndicators"; "required": false; "isSignal": true; }; "pauseOnFocus": { "alias": "pauseOnFocus"; "required": false; "isSignal": true; }; "indicatorsByChunk": { "alias": "indicatorsByChunk"; "required": false; "isSignal": true; }; "itemsPerSlide": { "alias": "itemsPerSlide"; "required": false; "isSignal": true; }; "singleSlideOffset": { "alias": "singleSlideOffset"; "required": false; "isSignal": true; }; "isAnimated": { "alias": "isAnimated"; "required": false; "isSignal": true; }; "activeSlideInput": { "alias": "activeSlide"; "required": false; "isSignal": true; }; "startFromIndex": { "alias": "startFromIndex"; "required": false; "isSignal": true; }; "interval": { "alias": "interval"; "required": false; "isSignal": true; }; }, { "activeSlideChange": "activeSlideChange"; "slideRangeChange": "slideRangeChange"; }, never, ["*"], true, never>;
}

declare class CarouselModule {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CarouselModule, never>;
    static ɵmod: _angular_core.ɵɵNgModuleDeclaration<CarouselModule, never, [typeof SlideComponent, typeof CarouselComponent], [typeof SlideComponent, typeof CarouselComponent]>;
    static ɵinj: _angular_core.ɵɵInjectorDeclaration<CarouselModule>;
}

export { CarouselComponent, CarouselConfig, CarouselModule, SlideComponent };
