import { Renderer2 } from '@angular/core';

/**
 * @copyright Valor Software
 * @copyright Angular ng-bootstrap team
 */
declare class Trigger {
    open: string;
    close?: string;
    constructor(open: string, close?: string);
    isManual(): boolean;
}

/**
 * @copyright Valor Software
 * @copyright Angular ng-bootstrap team
 */

type BsEventCallback = (event?: any) => boolean | void;
interface ListenOptions {
    target?: HTMLElement;
    targets?: HTMLElement[];
    triggers?: string;
    outsideClick?: boolean;
    outsideEsc?: boolean;
    show?: BsEventCallback;
    hide?: BsEventCallback;
    toggle?: BsEventCallback;
}
declare function parseTriggers(triggers?: string, aliases?: any): Trigger[];
declare function listenToTriggers(renderer: Renderer2, target: any, triggers: string, showFn: BsEventCallback, hideFn: BsEventCallback, toggleFn: BsEventCallback): () => void;
declare function listenToTriggersV2(renderer: Renderer2, options: ListenOptions): () => void;
declare function registerOutsideClick(renderer: Renderer2, options: ListenOptions): Function;
declare function registerEscClick(renderer: Renderer2, options: ListenOptions): Function;

type AvailableBsVersions = 'bs4' | 'bs5';
interface IObjectKeys {
    [key: string]: boolean;
}
interface IBsVersion extends IObjectKeys {
    isBs4: boolean;
    isBs5: boolean;
}
declare enum BsVerions {
    isBs4 = "bs4",
    isBs5 = "bs5"
}
declare function setTheme(theme: AvailableBsVersions): void;
declare function getBsVer(): IBsVersion;
declare function currentBsVersion(): AvailableBsVersions;

interface ListNode<T> {
    value: T;
    next?: ListNode<T>;
    previous?: ListNode<T>;
}
declare class LinkedList<T> {
    length: number;
    protected head?: ListNode<T>;
    protected tail?: ListNode<T>;
    protected current?: ListNode<T>;
    protected asArray: T[];
    get(position: number): T | undefined;
    add(value: T, position?: number): void;
    remove(position?: number): void;
    set(position: number, value: T): void;
    toArray(): T[];
    findAll(fn: (value: T, index: number) => boolean): {
        index: number;
        value: T;
    }[];
    push(...args: T[]): number;
    pop(): T | undefined;
    unshift(...args: T[]): number;
    shift(): T | undefined;
    forEach(fn: (value: T, index: number) => void): void;
    indexOf(value: T): number;
    some(fn: (value: T) => boolean): boolean;
    every(fn: (value: T) => boolean): boolean;
    toString(): string;
    find(fn: (value: T, index: number) => boolean): T | void;
    findIndex(fn: (value: T, index: number) => boolean): number;
    protected getNode(position: number): ListNode<T> | undefined;
    protected createInternalArrayRepresentation(): void;
}

declare function OnChange(): any;

declare class Utils {
    static reflow(element: any): void;
    static getStyles(elem: any): any;
    static stackOverflowConfig(): {
        crossorigin?: string;
        integrity?: string;
        cdnLink: string;
    };
}

/**
 * @license
 * Copyright Google Inc. All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */
/**
 * JS version of browser APIs. This library can only run in the browser.
 */
declare const win: any;

declare const document: any;

declare function warnOnce(msg: string): void;

/** Extra time given to the fallback timeout beyond the transition duration. */
declare const TRANSITION_FALLBACK_BUFFER_MS = 50;
interface TransitionFinishedRef {
    /** Removes the transitionend listener and clears the fallback timeout. Never calls onFinish. Idempotent. */
    cancel(): void;
}
/**
 * Waits for a CSS transition on `property` to finish on `el` and calls `onFinish` exactly once.
 *
 * Listens for `transitionend`, guarded against bubbled events from child elements and unrelated
 * properties. If the event never fires (e.g. the transition start and end values are equal),
 * a fallback timeout of `durationMs + TRANSITION_FALLBACK_BUFFER_MS` triggers `onFinish` instead.
 */
declare function onTransitionFinished(el: HTMLElement, property: string, durationMs: number, onFinish: () => void): TransitionFinishedRef;
interface ExpandAnimationOptions {
    /** CSS property to animate. `max-height` avoids conflicts with `height` bindings. Default: `height`. */
    property?: 'height' | 'max-height';
    /** CSS transition timing, e.g. `'220ms cubic-bezier(0, 0, 0.2, 1)'`. */
    timing: string;
    /** Transition duration in ms; drives the fallback timeout. */
    durationMs: number;
    /** Set the target size inside a requestAnimationFrame instead of synchronously after the reflow. */
    useRaf?: boolean;
    /** Set `display: block` before animating and remove it when finished. */
    manageDisplay?: boolean;
    /** Called after the inline styles are cleaned up. Not called when the animation is cancelled. */
    onDone?: () => void;
}
/**
 * Expands `el` from 0 to its scroll size with a native CSS transition on `height`/`max-height`.
 *
 * Pins the element at 0, forces a synchronous reflow so the browser registers the start value,
 * then sets the target size and lets the CSS engine interpolate. Inline styles are removed when
 * the transition ends (or the fallback timeout fires).
 *
 * Returns a cancel function for `ngOnDestroy`: it stops all pending work without removing
 * inline styles (the element is being torn down) and without calling `onDone`. Idempotent.
 */
declare function animateExpand(renderer: Renderer2, el: HTMLElement, options: ExpandAnimationOptions): () => void;

export { BsVerions, LinkedList, OnChange, TRANSITION_FALLBACK_BUFFER_MS, Trigger, Utils, animateExpand, currentBsVersion, document, getBsVer, listenToTriggers, listenToTriggersV2, onTransitionFinished, parseTriggers, registerEscClick, registerOutsideClick, setTheme, warnOnce, win as window };
export type { AvailableBsVersions, BsEventCallback, ExpandAnimationOptions, IBsVersion, ListenOptions, TransitionFinishedRef };
