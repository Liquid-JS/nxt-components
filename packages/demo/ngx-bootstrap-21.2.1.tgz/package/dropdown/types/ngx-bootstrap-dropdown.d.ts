import * as i0 from '@angular/core';
import { ViewContainerRef, TemplateRef, EventEmitter, OnInit, OnDestroy, ElementRef, Renderer2, ChangeDetectorRef } from '@angular/core';
import { BsComponentRef, ComponentLoaderFactory } from 'ngx-bootstrap/component-loader';

/** Default dropdown configuration */
declare class BsDropdownConfig {
    /** default dropdown auto closing behavior */
    autoClose: boolean;
    /** default dropdown auto closing behavior */
    insideClick: boolean;
    /** turn on/off animation */
    isAnimated: boolean;
    /** value true of stopOnClickPropagation allows event stopPropagation*/
    stopOnClickPropagation: boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<BsDropdownConfig, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<BsDropdownConfig>;
}

declare class BsDropdownMenuDirective {
    constructor(_state: BsDropdownState, _viewContainer: ViewContainerRef, _templateRef: TemplateRef<BsDropdownMenuDirective>);
    static ɵfac: i0.ɵɵFactoryDeclaration<BsDropdownMenuDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<BsDropdownMenuDirective, "[bsDropdownMenu],[dropdownMenu]", ["bs-dropdown-menu"], {}, {}, never, never, true, never>;
}

declare class BsDropdownState {
    direction: 'down' | 'up';
    autoClose: boolean;
    insideClick: boolean;
    isAnimated: boolean;
    stopOnClickPropagation: boolean;
    isOpenChange: EventEmitter<boolean>;
    isDisabledChange: EventEmitter<boolean>;
    toggleClick: EventEmitter<boolean>;
    counts: number;
    /**
     * Content to be displayed as popover.
     */
    dropdownMenu: Promise<BsComponentRef<BsDropdownMenuDirective>>;
    resolveDropdownMenu: (componentRef: BsComponentRef<BsDropdownMenuDirective>) => void;
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<BsDropdownState, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<BsDropdownState>;
}

declare class BsDropdownDirective implements OnInit, OnDestroy {
    private _elementRef;
    private _renderer;
    private _viewContainerRef;
    private _cis;
    private _state;
    private _config;
    /**
     * Placement of a popover. Accepts: "top", "bottom", "left", "right"
     */
    placement: i0.InputSignal<string | undefined>;
    /**
     * Specifies events that should trigger. Supports a space separated list of
     * event names.
     */
    triggers: i0.InputSignal<string | undefined>;
    /**
     * A selector specifying the element the popover should be appended to.
     */
    container: i0.InputSignal<string | undefined>;
    /**
     * This attribute indicates that the dropdown should be opened upwards
     */
    dropup: i0.InputSignal<boolean>;
    _dropup: boolean;
    /**
     * Indicates that dropdown will be closed on item or document click,
     * and after pressing ESC
     */
    autoClose: i0.InputSignal<boolean | undefined>;
    /**
     * Indicates that dropdown will be animated
     */
    isAnimated: i0.InputSignal<boolean | undefined>;
    /**
     * This attribute indicates that the dropdown shouldn't close on inside click when autoClose is set to true
     */
    insideClick: i0.InputSignal<boolean | undefined>;
    /**
     * Disables dropdown toggle and hides dropdown menu if opened
     */
    isDisabledInput: i0.InputSignal<boolean>;
    get isDisabled(): boolean;
    /**
     * Returns whether or not the popover is currently being shown
     */
    isOpenInput: i0.InputSignal<boolean>;
    get isOpen(): boolean;
    /**
     * Emits an event when isOpen change
     */
    readonly isOpenChange: i0.OutputEmitterRef<boolean>;
    /**
     * Emits an event when the popover is shown
     */
    readonly onShown: i0.OutputEmitterRef<boolean>;
    /**
     * Emits an event when the popover is hidden
     */
    readonly onHidden: i0.OutputEmitterRef<boolean>;
    private _dropdown;
    private get _showInline();
    private _isInlineOpen;
    private _inlinedMenu?;
    private _isDisabled;
    private _subscriptions;
    private _isInited;
    private _cancelExpandAnimation?;
    constructor(_elementRef: ElementRef, _renderer: Renderer2, _viewContainerRef: ViewContainerRef, _cis: ComponentLoaderFactory, _state: BsDropdownState, _config: BsDropdownConfig);
    ngOnInit(): void;
    /**
     * Opens an element’s popover. This is considered a “manual” triggering of
     * the popover.
     */
    show(): void;
    /**
     * Closes an element’s popover. This is considered a “manual” triggering of
     * the popover.
     */
    hide(): void;
    /**
     * Toggles an element’s popover. This is considered a “manual” triggering of
     * the popover. With parameter <code>true</code> allows toggling, with parameter <code>false</code>
     * only hides opened dropdown. Parameter usage will be removed in ngx-bootstrap v3
     */
    toggle(value?: boolean): void;
    /** @internal */
    _contains(event: Event): boolean;
    navigationClick(event: Event): void;
    ngOnDestroy(): void;
    private addBs4Polyfills;
    private playAnimation;
    private addShowClass;
    private removeShowClass;
    private checkRightAlignment;
    private addDropupStyles;
    private removeDropupStyles;
    static ɵfac: i0.ɵɵFactoryDeclaration<BsDropdownDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<BsDropdownDirective, "[bsDropdown], [dropdown]", ["bs-dropdown"], { "placement": { "alias": "placement"; "required": false; "isSignal": true; }; "triggers": { "alias": "triggers"; "required": false; "isSignal": true; }; "container": { "alias": "container"; "required": false; "isSignal": true; }; "dropup": { "alias": "dropup"; "required": false; "isSignal": true; }; "autoClose": { "alias": "autoClose"; "required": false; "isSignal": true; }; "isAnimated": { "alias": "isAnimated"; "required": false; "isSignal": true; }; "insideClick": { "alias": "insideClick"; "required": false; "isSignal": true; }; "isDisabledInput": { "alias": "isDisabled"; "required": false; "isSignal": true; }; "isOpenInput": { "alias": "isOpen"; "required": false; "isSignal": true; }; }, { "isOpenChange": "isOpenChange"; "onShown": "onShown"; "onHidden": "onHidden"; }, never, never, true, never>;
}

declare class BsDropdownToggleDirective implements OnDestroy {
    private _changeDetectorRef;
    private _dropdown;
    private _element;
    private _renderer;
    private _state;
    isDisabled: undefined | true;
    isOpen: boolean;
    private _subscriptions;
    private _documentClickListener?;
    private _escKeyUpListener?;
    constructor(_changeDetectorRef: ChangeDetectorRef, _dropdown: BsDropdownDirective, _element: ElementRef, _renderer: Renderer2, _state: BsDropdownState);
    onClick(event: MouseEvent): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<BsDropdownToggleDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<BsDropdownToggleDirective, "[bsDropdownToggle],[dropdownToggle]", ["bs-dropdown-toggle"], {}, {}, never, never, true, never>;
}

declare class BsDropdownContainerComponent implements OnDestroy {
    private _state;
    private cd;
    private _renderer;
    private _element;
    isOpen: boolean;
    get direction(): 'down' | 'up';
    private _subscription;
    private _cancelExpandAnimation?;
    constructor(_state: BsDropdownState, cd: ChangeDetectorRef, _renderer: Renderer2, _element: ElementRef);
    /** @internal */
    _contains(el: Element): boolean;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<BsDropdownContainerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BsDropdownContainerComponent, "bs-dropdown-container", never, {}, {}, never, ["*"], true, never>;
}

declare class BsDropdownModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<BsDropdownModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<BsDropdownModule, never, [typeof BsDropdownDirective, typeof BsDropdownContainerComponent, typeof BsDropdownMenuDirective, typeof BsDropdownToggleDirective], [typeof BsDropdownMenuDirective, typeof BsDropdownToggleDirective, typeof BsDropdownDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<BsDropdownModule>;
}

export { BsDropdownConfig, BsDropdownContainerComponent, BsDropdownDirective, BsDropdownMenuDirective, BsDropdownModule, BsDropdownState, BsDropdownToggleDirective };
