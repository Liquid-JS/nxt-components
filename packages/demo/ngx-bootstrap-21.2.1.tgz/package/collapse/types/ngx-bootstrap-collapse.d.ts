import * as _angular_core from '@angular/core';
import { AfterViewChecked, OnDestroy, ElementRef, Renderer2 } from '@angular/core';

declare class CollapseDirective implements AfterViewChecked, OnDestroy {
    private _el;
    private _renderer;
    /** This event fires as soon as content collapses */
    collapsed: _angular_core.OutputEmitterRef<CollapseDirective>;
    /** This event fires when collapsing is started */
    collapses: _angular_core.OutputEmitterRef<CollapseDirective>;
    /** This event fires as soon as content becomes visible */
    expanded: _angular_core.OutputEmitterRef<CollapseDirective>;
    /** This event fires when expansion is started */
    expands: _angular_core.OutputEmitterRef<CollapseDirective>;
    isExpanded: boolean;
    collapseNewValue: boolean;
    isCollapsed: boolean;
    isCollapse: boolean;
    isCollapsing: boolean;
    display: _angular_core.InputSignal<string>;
    /** turn on/off animation */
    isAnimated: _angular_core.InputSignal<boolean>;
    /** A flag indicating visibility of content (shown or hidden) */
    collapse: _angular_core.InputSignal<boolean>;
    private _display;
    private _isAnimationDone?;
    private _stylesLoaded;
    private _isTransitionRunning;
    private _pendingFinish?;
    private _rafId?;
    private _COLLAPSE_ACTION_NAME;
    private _EXPAND_ACTION_NAME;
    constructor(_el: ElementRef, _renderer: Renderer2);
    ngAfterViewChecked(): void;
    /** allows to manually toggle content visibility */
    toggle(): void;
    /** allows to manually hide content */
    hide(): void;
    /** allows to manually show collapsed content */
    show(): void;
    animationRun(isAnimated: boolean, action: string): (callback: () => void) => void;
    ngOnDestroy(): void;
    private _cancelPending;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CollapseDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<CollapseDirective, "[collapse]", ["bs-collapse"], { "display": { "alias": "display"; "required": false; "isSignal": true; }; "isAnimated": { "alias": "isAnimated"; "required": false; "isSignal": true; }; "collapse": { "alias": "collapse"; "required": false; "isSignal": true; }; }, { "collapsed": "collapsed"; "collapses": "collapses"; "expanded": "expanded"; "expands": "expands"; }, never, never, true, never>;
}

declare class CollapseModule {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CollapseModule, never>;
    static ɵmod: _angular_core.ɵɵNgModuleDeclaration<CollapseModule, never, [typeof CollapseDirective], [typeof CollapseDirective]>;
    static ɵinj: _angular_core.ɵɵInjectorDeclaration<CollapseModule>;
}

export { CollapseDirective, CollapseModule };
