import * as _angular_core from '@angular/core';
import { ElementRef, Renderer2 } from '@angular/core';

type ProgressbarType = 'success' | 'info' | 'warning' | 'danger';
interface BarValue {
    type: ProgressbarType;
    label: string;
    value: number;
    max: number;
}

declare class BarComponent {
    private el;
    private renderer;
    /** maximum total value of progress element */
    max: _angular_core.InputSignal<number>;
    /** current value of progress bar */
    value: _angular_core.InputSignal<number | undefined>;
    /** if `true` changing value of progress bar will be animated */
    animate: _angular_core.InputSignal<boolean | undefined>;
    /** If `true`, striped classes are applied */
    striped: _angular_core.InputSignal<boolean | undefined>;
    /** provide one of the four supported contextual classes: `success`, `info`, `warning`, `danger` */
    type: _angular_core.InputSignal<ProgressbarType | undefined>;
    percent: number;
    private _prevType?;
    constructor(el: ElementRef, renderer: Renderer2);
    private applyTypeClasses;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BarComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<BarComponent, "bar", never, { "max": { "alias": "max"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "animate": { "alias": "animate"; "required": false; "isSignal": true; }; "striped": { "alias": "striped"; "required": false; "isSignal": true; }; "type": { "alias": "type"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

declare class ProgressbarConfig {
    /** if `true` changing value of progress bar will be animated */
    animate: boolean;
    /** If `true`, striped classes are applied */
    striped: boolean;
    /** maximum total value of progress element */
    max: number;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ProgressbarConfig, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<ProgressbarConfig>;
}

declare class ProgressbarComponent {
    private _config;
    /** maximum total value of progress element */
    max: _angular_core.InputSignal<number>;
    /** if `true` changing value of progress bar will be animated */
    animate: _angular_core.InputSignal<boolean>;
    /** If `true`, striped classes are applied */
    striped: _angular_core.InputSignal<boolean>;
    /** provide one of the four supported contextual classes: `success`, `info`, `warning`, `danger` */
    type: _angular_core.InputSignal<ProgressbarType | undefined>;
    /** current value of progress bar. Could be a number or array of objects
     * like {"value":15,"type":"info","label":"15 %"}
     */
    value: _angular_core.InputSignal<number | BarValue[]>;
    isStacked: _angular_core.Signal<boolean>;
    _value: _angular_core.Signal<number | undefined>;
    _values: _angular_core.Signal<BarValue[] | undefined>;
    constructor(_config: ProgressbarConfig);
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ProgressbarComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<ProgressbarComponent, "progressbar", never, { "max": { "alias": "max"; "required": false; "isSignal": true; }; "animate": { "alias": "animate"; "required": false; "isSignal": true; }; "striped": { "alias": "striped"; "required": false; "isSignal": true; }; "type": { "alias": "type"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

declare class ProgressbarModule {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ProgressbarModule, never>;
    static ɵmod: _angular_core.ɵɵNgModuleDeclaration<ProgressbarModule, never, [typeof BarComponent, typeof ProgressbarComponent], [typeof BarComponent, typeof ProgressbarComponent]>;
    static ɵinj: _angular_core.ɵɵInjectorDeclaration<ProgressbarModule>;
}

export { BarComponent, ProgressbarComponent, ProgressbarConfig, ProgressbarModule };
export type { ProgressbarType };
