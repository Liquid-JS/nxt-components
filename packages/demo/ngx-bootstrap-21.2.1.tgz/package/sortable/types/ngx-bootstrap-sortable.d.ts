import * as _angular_core from '@angular/core';
import { TemplateRef } from '@angular/core';
import { ControlValueAccessor } from '@angular/forms';
import { Subject } from 'rxjs';

interface DraggableItem {
    event: DragEvent;
    item: any;
    i: number;
    initialIndex: number;
    lastZoneIndex: number;
    overZoneIndex: number;
}

declare class DraggableItemService {
    private draggableItem?;
    private onCapture;
    dragStart(item: DraggableItem): void;
    getItem(): DraggableItem | undefined;
    captureItem(overZoneIndex: number, newIndex: number): DraggableItem | undefined;
    onCaptureItem(): Subject<DraggableItem>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<DraggableItemService, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<DraggableItemService>;
}

declare class SortableComponent implements ControlValueAccessor {
    private static globalZoneIndex;
    /** field name if input array consists of objects */
    fieldName: _angular_core.InputSignal<string | undefined>;
    /** class name for items wrapper */
    wrapperClass: _angular_core.InputSignal<string>;
    /** style object for items wrapper */
    wrapperStyle: _angular_core.InputSignal<Record<string, string>>;
    /** class name for item */
    itemClass: _angular_core.InputSignal<string>;
    /** style object for item */
    itemStyle: _angular_core.InputSignal<Record<string, string>>;
    /** class name for active item */
    itemActiveClass: _angular_core.InputSignal<string>;
    /** style object for active item */
    itemActiveStyle: _angular_core.InputSignal<Record<string, string>>;
    /** class name for placeholder */
    placeholderClass: _angular_core.InputSignal<string>;
    /** style object for placeholder */
    placeholderStyle: _angular_core.InputSignal<Record<string, string>>;
    /** placeholder item which will be shown if collection is empty */
    placeholderItem: _angular_core.InputSignal<string>;
    /** used to specify a custom item template. Template variables: item and index; */
    itemTemplate: _angular_core.InputSignal<TemplateRef<unknown> | undefined>;
    /** fired on array change (reordering, insert, remove), same as <code>ngModelChange</code>.
     *  Returns new items collection as a payload.
     */
    onChange: _angular_core.OutputEmitterRef<unknown[]>;
    showPlaceholder: boolean;
    activeItem: number;
    get items(): SortableItem[];
    set items(value: SortableItem[]);
    onTouched: any;
    onChanged: any;
    private transfer;
    private currentZoneIndex;
    private _items;
    constructor(transfer: DraggableItemService);
    onItemDragstart(event: DragEvent, item: SortableItem, i: number): void;
    onItemDragover(event: DragEvent, i: number): void;
    cancelEvent(event?: DragEvent | MouseEvent): void;
    onDrop(item: DraggableItem): void;
    resetActiveItem(event?: DragEvent | MouseEvent): void;
    registerOnChange(callback: () => void): void;
    registerOnTouched(callback: () => void): void;
    writeValue(value: any[]): void;
    updatePlaceholderState(): void;
    getItemStyle(isActive: boolean): Record<string, string>;
    private initDragstartEvent;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SortableComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SortableComponent, "bs-sortable", ["bs-sortable"], { "fieldName": { "alias": "fieldName"; "required": false; "isSignal": true; }; "wrapperClass": { "alias": "wrapperClass"; "required": false; "isSignal": true; }; "wrapperStyle": { "alias": "wrapperStyle"; "required": false; "isSignal": true; }; "itemClass": { "alias": "itemClass"; "required": false; "isSignal": true; }; "itemStyle": { "alias": "itemStyle"; "required": false; "isSignal": true; }; "itemActiveClass": { "alias": "itemActiveClass"; "required": false; "isSignal": true; }; "itemActiveStyle": { "alias": "itemActiveStyle"; "required": false; "isSignal": true; }; "placeholderClass": { "alias": "placeholderClass"; "required": false; "isSignal": true; }; "placeholderStyle": { "alias": "placeholderStyle"; "required": false; "isSignal": true; }; "placeholderItem": { "alias": "placeholderItem"; "required": false; "isSignal": true; }; "itemTemplate": { "alias": "itemTemplate"; "required": false; "isSignal": true; }; }, { "onChange": "onChange"; }, never, never, true, never>;
}
declare interface SortableItem {
    id: number;
    value: string;
    initData: any;
}

declare class SortableModule {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SortableModule, never>;
    static ɵmod: _angular_core.ɵɵNgModuleDeclaration<SortableModule, never, [typeof SortableComponent], [typeof SortableComponent]>;
    static ɵinj: _angular_core.ɵɵInjectorDeclaration<SortableModule>;
}

export { DraggableItemService, SortableComponent, SortableModule };
export type { DraggableItem, SortableItem };
