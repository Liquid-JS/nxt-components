import * as i0 from '@angular/core';
import { Injectable, input, output, forwardRef, Component, NgModule } from '@angular/core';
import { NG_VALUE_ACCESSOR } from '@angular/forms';
import { Subject } from 'rxjs';
import { NgClass, NgStyle, NgTemplateOutlet } from '@angular/common';

class DraggableItemService {
    constructor() {
        this.onCapture = new Subject();
    }
    dragStart(item) {
        this.draggableItem = item;
    }
    getItem() {
        return this.draggableItem;
    }
    captureItem(overZoneIndex, newIndex) {
        if (this.draggableItem && this.draggableItem.overZoneIndex !== overZoneIndex) {
            this.draggableItem.lastZoneIndex = this.draggableItem.overZoneIndex;
            this.draggableItem.overZoneIndex = overZoneIndex;
            this.onCapture.next(this.draggableItem);
            this.draggableItem = Object.assign({}, this.draggableItem, {
                overZoneIndex,
                i: newIndex
            });
        }
        return this.draggableItem;
    }
    onCaptureItem() {
        return this.onCapture;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.0", ngImport: i0, type: DraggableItemService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.0", ngImport: i0, type: DraggableItemService, providedIn: 'platform' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.0", ngImport: i0, type: DraggableItemService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'platform' }]
        }] });

class SortableComponent {
    static { this.globalZoneIndex = 0; }
    get items() {
        return this._items;
    }
    set items(value) {
        this._items = value;
        const out = this.items.map((x) => x.initData);
        this.onChanged(out);
        this.onChange.emit(out);
    }
    constructor(transfer) {
        /** field name if input array consists of objects */
        this.fieldName = input(...(ngDevMode ? [undefined, { debugName: "fieldName" }] : []));
        /** class name for items wrapper */
        this.wrapperClass = input('', ...(ngDevMode ? [{ debugName: "wrapperClass" }] : []));
        /** style object for items wrapper */
        this.wrapperStyle = input({}, ...(ngDevMode ? [{ debugName: "wrapperStyle" }] : []));
        /** class name for item */
        this.itemClass = input('', ...(ngDevMode ? [{ debugName: "itemClass" }] : []));
        /** style object for item */
        this.itemStyle = input({}, ...(ngDevMode ? [{ debugName: "itemStyle" }] : []));
        /** class name for active item */
        this.itemActiveClass = input('', ...(ngDevMode ? [{ debugName: "itemActiveClass" }] : []));
        /** style object for active item */
        this.itemActiveStyle = input({}, ...(ngDevMode ? [{ debugName: "itemActiveStyle" }] : []));
        /** class name for placeholder */
        this.placeholderClass = input('', ...(ngDevMode ? [{ debugName: "placeholderClass" }] : []));
        /** style object for placeholder */
        this.placeholderStyle = input({}, ...(ngDevMode ? [{ debugName: "placeholderStyle" }] : []));
        /** placeholder item which will be shown if collection is empty */
        this.placeholderItem = input('', ...(ngDevMode ? [{ debugName: "placeholderItem" }] : []));
        /** used to specify a custom item template. Template variables: item and index; */
        this.itemTemplate = input(...(ngDevMode ? [undefined, { debugName: "itemTemplate" }] : []));
        /** fired on array change (reordering, insert, remove), same as <code>ngModelChange</code>.
         *  Returns new items collection as a payload.
         */
        this.onChange = output();
        this.showPlaceholder = false;
        this.activeItem = -1;
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        this.onTouched = Function.prototype;
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        this.onChanged = Function.prototype;
        this._items = [];
        this.transfer = transfer;
        this.currentZoneIndex = SortableComponent.globalZoneIndex++;
        this.transfer
            .onCaptureItem()
            .subscribe((item) => this.onDrop(item));
    }
    onItemDragstart(event, item, i) {
        this.initDragstartEvent(event);
        this.onTouched();
        this.transfer.dragStart({
            event,
            item,
            i,
            initialIndex: i,
            lastZoneIndex: this.currentZoneIndex,
            overZoneIndex: this.currentZoneIndex
        });
    }
    onItemDragover(event, i) {
        if (!this.transfer.getItem()) {
            return;
        }
        event.preventDefault();
        const dragItem = this.transfer.captureItem(this.currentZoneIndex, this.items.length);
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        let newArray = [];
        if (!dragItem) {
            return;
        }
        if (!this.items.length) {
            newArray = [dragItem.item];
        }
        else if (dragItem.i > i) {
            newArray = [
                ...this.items.slice(0, i),
                dragItem.item,
                ...this.items.slice(i, dragItem.i),
                ...this.items.slice(dragItem.i + 1)
            ];
        }
        else {
            // this.draggedItem.i < i
            newArray = [
                ...this.items.slice(0, dragItem.i),
                ...this.items.slice(dragItem.i + 1, i + 1),
                dragItem.item,
                ...this.items.slice(i + 1)
            ];
        }
        this.items = newArray;
        dragItem.i = i;
        this.activeItem = i;
        this.updatePlaceholderState();
    }
    cancelEvent(event) {
        if (!this.transfer.getItem() || !event) {
            return;
        }
        event.preventDefault();
    }
    onDrop(item) {
        if (item &&
            item.overZoneIndex !== this.currentZoneIndex &&
            item.lastZoneIndex === this.currentZoneIndex) {
            this.items = this.items.filter((x, i) => i !== item.i);
            this.updatePlaceholderState();
        }
        this.resetActiveItem();
    }
    resetActiveItem(event) {
        this.cancelEvent(event);
        this.activeItem = -1;
    }
    registerOnChange(callback) {
        this.onChanged = callback;
    }
    registerOnTouched(callback) {
        this.onTouched = callback;
    }
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    writeValue(value) {
        if (value) {
            const fieldNameValue = this.fieldName();
            // eslint-disable-next-line @typescript-eslint/no-explicit-any
            this.items = value.map((x, i) => ({
                id: i,
                initData: x,
                value: fieldNameValue ? x[fieldNameValue] : x
            }));
        }
        else {
            this.items = [];
        }
        this.updatePlaceholderState();
    }
    updatePlaceholderState() {
        this.showPlaceholder = !this._items.length;
    }
    getItemStyle(isActive) {
        return isActive
            ? Object.assign({}, this.itemStyle(), this.itemActiveStyle())
            : this.itemStyle();
    }
    initDragstartEvent(event) {
        // it is necessary for mozilla
        // data type should be 'Text' instead of 'text/plain' to keep compatibility
        // with IE
        event.dataTransfer?.setData('Text', 'placeholder');
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.0", ngImport: i0, type: SortableComponent, deps: [{ token: DraggableItemService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.0", type: SortableComponent, isStandalone: true, selector: "bs-sortable", inputs: { fieldName: { classPropertyName: "fieldName", publicName: "fieldName", isSignal: true, isRequired: false, transformFunction: null }, wrapperClass: { classPropertyName: "wrapperClass", publicName: "wrapperClass", isSignal: true, isRequired: false, transformFunction: null }, wrapperStyle: { classPropertyName: "wrapperStyle", publicName: "wrapperStyle", isSignal: true, isRequired: false, transformFunction: null }, itemClass: { classPropertyName: "itemClass", publicName: "itemClass", isSignal: true, isRequired: false, transformFunction: null }, itemStyle: { classPropertyName: "itemStyle", publicName: "itemStyle", isSignal: true, isRequired: false, transformFunction: null }, itemActiveClass: { classPropertyName: "itemActiveClass", publicName: "itemActiveClass", isSignal: true, isRequired: false, transformFunction: null }, itemActiveStyle: { classPropertyName: "itemActiveStyle", publicName: "itemActiveStyle", isSignal: true, isRequired: false, transformFunction: null }, placeholderClass: { classPropertyName: "placeholderClass", publicName: "placeholderClass", isSignal: true, isRequired: false, transformFunction: null }, placeholderStyle: { classPropertyName: "placeholderStyle", publicName: "placeholderStyle", isSignal: true, isRequired: false, transformFunction: null }, placeholderItem: { classPropertyName: "placeholderItem", publicName: "placeholderItem", isSignal: true, isRequired: false, transformFunction: null }, itemTemplate: { classPropertyName: "itemTemplate", publicName: "itemTemplate", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { onChange: "onChange" }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => SortableComponent),
                multi: true
            }
        ], exportAs: ["bs-sortable"], ngImport: i0, template: `
<div
  [ngClass]="wrapperClass()"
  [ngStyle]="wrapperStyle()"
  (dragover)="cancelEvent($event)"
  (dragenter)="cancelEvent($event)"
  (drop)="resetActiveItem($event)"
  (mouseleave)="resetActiveItem($event)">
  @if (showPlaceholder) {
    <div
      [ngClass]="placeholderClass()"
      [ngStyle]="placeholderStyle()"
      (dragover)="onItemDragover($event, 0)"
      (dragenter)="cancelEvent($event)"
    >{{placeholderItem()}}</div>
  }
  @for (item of items; track item; let i = $index) {
    <div
      [ngClass]="[ itemClass(), i === activeItem ? itemActiveClass() : '' ]"
      [ngStyle]="getItemStyle(i === activeItem)"
      draggable="true"
      (dragstart)="onItemDragstart($event, item, i)"
      (dragend)="resetActiveItem($event)"
      (dragover)="onItemDragover($event, i)"
      (dragenter)="cancelEvent($event)"
      aria-dropeffect="move"
      [attr.aria-grabbed]="i === activeItem"
      ><ng-template [ngTemplateOutlet]="itemTemplate() || defItemTemplate"
    [ngTemplateOutletContext]="{item:item, index: i}"></ng-template></div>
  }
</div>

<ng-template #defItemTemplate let-item="item">{{item.value}}</ng-template>
`, isInline: true, dependencies: [{ kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: NgStyle, selector: "[ngStyle]", inputs: ["ngStyle"] }, { kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.0", ngImport: i0, type: SortableComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'bs-sortable',
                    exportAs: 'bs-sortable',
                    template: `
<div
  [ngClass]="wrapperClass()"
  [ngStyle]="wrapperStyle()"
  (dragover)="cancelEvent($event)"
  (dragenter)="cancelEvent($event)"
  (drop)="resetActiveItem($event)"
  (mouseleave)="resetActiveItem($event)">
  @if (showPlaceholder) {
    <div
      [ngClass]="placeholderClass()"
      [ngStyle]="placeholderStyle()"
      (dragover)="onItemDragover($event, 0)"
      (dragenter)="cancelEvent($event)"
    >{{placeholderItem()}}</div>
  }
  @for (item of items; track item; let i = $index) {
    <div
      [ngClass]="[ itemClass(), i === activeItem ? itemActiveClass() : '' ]"
      [ngStyle]="getItemStyle(i === activeItem)"
      draggable="true"
      (dragstart)="onItemDragstart($event, item, i)"
      (dragend)="resetActiveItem($event)"
      (dragover)="onItemDragover($event, i)"
      (dragenter)="cancelEvent($event)"
      aria-dropeffect="move"
      [attr.aria-grabbed]="i === activeItem"
      ><ng-template [ngTemplateOutlet]="itemTemplate() || defItemTemplate"
    [ngTemplateOutletContext]="{item:item, index: i}"></ng-template></div>
  }
</div>

<ng-template #defItemTemplate let-item="item">{{item.value}}</ng-template>
`,
                    providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => SortableComponent),
                            multi: true
                        }
                    ],
                    standalone: true,
                    imports: [NgClass, NgStyle, NgTemplateOutlet]
                }]
        }], ctorParameters: () => [{ type: DraggableItemService }], propDecorators: { fieldName: [{ type: i0.Input, args: [{ isSignal: true, alias: "fieldName", required: false }] }], wrapperClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "wrapperClass", required: false }] }], wrapperStyle: [{ type: i0.Input, args: [{ isSignal: true, alias: "wrapperStyle", required: false }] }], itemClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "itemClass", required: false }] }], itemStyle: [{ type: i0.Input, args: [{ isSignal: true, alias: "itemStyle", required: false }] }], itemActiveClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "itemActiveClass", required: false }] }], itemActiveStyle: [{ type: i0.Input, args: [{ isSignal: true, alias: "itemActiveStyle", required: false }] }], placeholderClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "placeholderClass", required: false }] }], placeholderStyle: [{ type: i0.Input, args: [{ isSignal: true, alias: "placeholderStyle", required: false }] }], placeholderItem: [{ type: i0.Input, args: [{ isSignal: true, alias: "placeholderItem", required: false }] }], itemTemplate: [{ type: i0.Input, args: [{ isSignal: true, alias: "itemTemplate", required: false }] }], onChange: [{ type: i0.Output, args: ["onChange"] }] } });

class SortableModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.0", ngImport: i0, type: SortableModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.0", ngImport: i0, type: SortableModule, imports: [SortableComponent], exports: [SortableComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.0", ngImport: i0, type: SortableModule }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.0", ngImport: i0, type: SortableModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [SortableComponent],
                    exports: [SortableComponent]
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { DraggableItemService, SortableComponent, SortableModule };
//# sourceMappingURL=ngx-bootstrap-sortable.mjs.map
