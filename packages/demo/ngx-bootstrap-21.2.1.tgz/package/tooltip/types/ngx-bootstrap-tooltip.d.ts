import * as _angular_core from '@angular/core';
import { AfterViewInit, OnInit, OnDestroy, TemplateRef, EventEmitter, ViewContainerRef, ElementRef, Renderer2 } from '@angular/core';
import { IBsVersion } from 'ngx-bootstrap/utils';
import { ComponentLoaderFactory } from 'ngx-bootstrap/component-loader';
import { AvailableBSPositions, PositioningService } from 'ngx-bootstrap/positioning';
import * as i1 from '@angular/common';

/** Default values provider for tooltip */
declare class TooltipConfig {
    /** sets disable adaptive position */
    adaptivePosition: boolean;
    /** tooltip placement, supported positions: 'top', 'bottom', 'left', 'right' */
    placement: string;
    /** array of event names which triggers tooltip opening */
    triggers: string;
    /** a selector specifying the element the tooltip should be appended to. */
    container?: string;
    /** delay before showing the tooltip */
    delay: number;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TooltipConfig, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<TooltipConfig>;
}

declare class TooltipContainerComponent implements AfterViewInit {
    classMap?: {
        [key: string]: boolean;
    };
    placement?: string;
    containerClass?: string;
    animation?: boolean;
    id?: string;
    get _bsVersions(): IBsVersion;
    constructor(config: TooltipConfig);
    ngAfterViewInit(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TooltipContainerComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<TooltipContainerComponent, "bs-tooltip-container", never, {}, {}, never, ["*"], true, never>;
}

declare class TooltipDirective implements OnInit, OnDestroy {
    private _config;
    private _elementRef;
    private _renderer;
    private _positionService;
    tooltipId: number;
    /** sets disable adaptive position */
    readonly adaptivePosition: _angular_core.InputSignal<boolean>;
    /**
     * Content to be displayed as tooltip.
     */
    readonly tooltip: _angular_core.ModelSignal<string | TemplateRef<unknown> | undefined>;
    /**
     * Placement of a tooltip. Accepts: "top", "bottom", "left", "right"
     */
    readonly placement: _angular_core.InputSignal<AvailableBSPositions>;
    /**
     * Specifies events that should trigger. Supports a space separated list of
     * event names.
     */
    readonly triggers: _angular_core.InputSignal<string>;
    /**
     * A selector specifying the element the tooltip should be appended to.
     */
    readonly container: _angular_core.InputSignal<string | undefined>;
    /**
     * Css class for tooltip container
     */
    readonly containerClass: _angular_core.InputSignal<string>;
    readonly boundariesElement: _angular_core.InputSignal<"viewport" | "scrollParent" | "window" | undefined>;
    /**
     * Returns whether or not the tooltip is currently being shown
     */
    get isOpen(): boolean;
    set isOpen(value: boolean);
    /**
     * Allows to disable tooltip
     */
    readonly isDisabled: _angular_core.InputSignal<boolean>;
    /**
     * Delay before showing the tooltip
     */
    readonly delay: _angular_core.InputSignal<number>;
    /**
     * Emits an event when the tooltip is shown
     */
    onShown: EventEmitter<unknown>;
    /**
     * Emits an event when the tooltip is hidden
     */
    onHidden: EventEmitter<unknown>;
    /** @deprecated - please use `tooltip` instead */
    readonly tooltipHtml: _angular_core.InputSignal<string | TemplateRef<unknown> | undefined>;
    /** @deprecated - please use `placement` instead */
    readonly tooltipPlacement: _angular_core.InputSignal<AvailableBSPositions | undefined>;
    /** @deprecated - please use `isOpen` instead */
    readonly tooltipIsOpen: _angular_core.InputSignal<boolean | undefined>;
    /** @deprecated - please use `isDisabled` instead */
    readonly tooltipEnable: _angular_core.InputSignal<boolean | undefined>;
    /** @deprecated - please use `container="body"` instead */
    readonly tooltipAppendToBody: _angular_core.InputSignal<boolean | undefined>;
    /** @deprecated - removed, will be added to configuration */
    readonly tooltipAnimation: _angular_core.InputSignal<boolean>;
    /** @deprecated - will replaced with customClass */
    readonly tooltipClass: _angular_core.InputSignal<string | undefined>;
    /** @deprecated - removed */
    readonly tooltipContext: _angular_core.InputSignal<undefined>;
    /** @deprecated */
    readonly tooltipPopupDelay: _angular_core.InputSignal<number | undefined>;
    /** @deprecated */
    readonly tooltipFadeDuration: _angular_core.InputSignal<number>;
    /** @deprecated -  please use `triggers` instead */
    readonly tooltipTrigger: _angular_core.InputSignal<string | string[] | undefined>;
    /** @deprecated */
    readonly tooltipStateChanged: _angular_core.OutputEmitterRef<boolean>;
    protected _delayTimeoutId?: number;
    protected _tooltipCancelShowFn?: () => void;
    private _tooltip;
    private _delaySubscription?;
    private _ariaDescribedby?;
    constructor(_viewContainerRef: ViewContainerRef, cis: ComponentLoaderFactory, _config: TooltipConfig, _elementRef: ElementRef, _renderer: Renderer2, _positionService: PositioningService);
    ngOnInit(): void;
    setAriaDescribedBy(): void;
    /**
     * Toggles an element's tooltip. This is considered a "manual" triggering of
     * the tooltip.
     */
    toggle(): void;
    /**
     * Opens an element's tooltip. This is considered a "manual" triggering of
     * the tooltip.
     */
    show(): void;
    /**
     * Closes an element's tooltip. This is considered a "manual" triggering of
     * the tooltip.
     */
    hide(): void;
    ngOnDestroy(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TooltipDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<TooltipDirective, "[tooltip], [tooltipHtml]", ["bs-tooltip"], { "adaptivePosition": { "alias": "adaptivePosition"; "required": false; "isSignal": true; }; "tooltip": { "alias": "tooltip"; "required": false; "isSignal": true; }; "placement": { "alias": "placement"; "required": false; "isSignal": true; }; "triggers": { "alias": "triggers"; "required": false; "isSignal": true; }; "container": { "alias": "container"; "required": false; "isSignal": true; }; "containerClass": { "alias": "containerClass"; "required": false; "isSignal": true; }; "boundariesElement": { "alias": "boundariesElement"; "required": false; "isSignal": true; }; "isDisabled": { "alias": "isDisabled"; "required": false; "isSignal": true; }; "delay": { "alias": "delay"; "required": false; "isSignal": true; }; "tooltipHtml": { "alias": "tooltipHtml"; "required": false; "isSignal": true; }; "tooltipPlacement": { "alias": "tooltipPlacement"; "required": false; "isSignal": true; }; "tooltipIsOpen": { "alias": "tooltipIsOpen"; "required": false; "isSignal": true; }; "tooltipEnable": { "alias": "tooltipEnable"; "required": false; "isSignal": true; }; "tooltipAppendToBody": { "alias": "tooltipAppendToBody"; "required": false; "isSignal": true; }; "tooltipAnimation": { "alias": "tooltipAnimation"; "required": false; "isSignal": true; }; "tooltipClass": { "alias": "tooltipClass"; "required": false; "isSignal": true; }; "tooltipContext": { "alias": "tooltipContext"; "required": false; "isSignal": true; }; "tooltipPopupDelay": { "alias": "tooltipPopupDelay"; "required": false; "isSignal": true; }; "tooltipFadeDuration": { "alias": "tooltipFadeDuration"; "required": false; "isSignal": true; }; "tooltipTrigger": { "alias": "tooltipTrigger"; "required": false; "isSignal": true; }; }, { "tooltip": "tooltipChange"; "tooltipStateChanged": "tooltipStateChanged"; }, never, never, true, never>;
}

declare class TooltipModule {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TooltipModule, never>;
    static ɵmod: _angular_core.ɵɵNgModuleDeclaration<TooltipModule, never, [typeof i1.CommonModule, typeof TooltipDirective, typeof TooltipContainerComponent], [typeof TooltipDirective]>;
    static ɵinj: _angular_core.ɵɵInjectorDeclaration<TooltipModule>;
}

export { TooltipConfig, TooltipContainerComponent, TooltipDirective, TooltipModule };
