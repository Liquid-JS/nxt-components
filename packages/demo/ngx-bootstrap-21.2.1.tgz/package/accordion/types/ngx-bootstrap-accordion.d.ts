import * as i0 from '@angular/core';
import { OnInit, OnDestroy } from '@angular/core';

/**
 * Configuration service, provides default values for the AccordionComponent.
 */
declare class AccordionConfig {
    /** Whether the other panels should be closed when a panel is opened */
    closeOthers: boolean;
    /** turn on/off animation */
    isAnimated: boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<AccordionConfig, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AccordionConfig>;
}

/** Displays collapsible content panels for presenting information in a limited amount of space. */
declare class AccordionComponent {
    private _config;
    /** turn on/off animation */
    isAnimated: i0.InputSignal<boolean>;
    /** if `true` expanding one item will close all others */
    closeOthers: i0.InputSignal<boolean>;
    protected groups: AccordionPanelComponent[];
    constructor(_config: AccordionConfig);
    closeOtherPanels(openGroup: AccordionPanelComponent): void;
    addGroup(group: AccordionPanelComponent): void;
    removeGroup(group: AccordionPanelComponent): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AccordionComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AccordionComponent, "accordion", never, { "isAnimated": { "alias": "isAnimated"; "required": false; "isSignal": true; }; "closeOthers": { "alias": "closeOthers"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

/**
 * ### Accordion heading
 * Instead of using `heading` attribute on the `accordion-group`, you can use
 * an `accordion-heading` attribute on `any` element inside of a group that
 * will be used as group's header template.
 */
declare class AccordionPanelComponent implements OnInit, OnDestroy {
    /** turn on/off animation */
    isAnimated: boolean;
    /** Clickable text in accordion's group header, check `accordion heading` below for using html in header */
    heading: i0.InputSignal<string>;
    /** Provides an ability to use Bootstrap's contextual panel classes
     * (`panel-primary`, `panel-success`, `panel-info`, etc...).
     * List of all available classes [available here]
     * (https://getbootstrap.com/docs/3.3/components/#panels-alternatives)
     */
    panelClass: i0.InputSignal<string>;
    /** if <code>true</code> — disables accordion group */
    isDisabled: i0.InputSignal<boolean>;
    /** Input to set initial open state */
    isOpenInput: i0.InputSignal<boolean>;
    /** Emits when the opened state changes */
    isOpenChange: i0.OutputEmitterRef<boolean>;
    /** Is accordion group open or closed. This property supports two-way binding */
    get isOpen(): boolean;
    set isOpen(value: boolean);
    protected _isOpen: boolean;
    protected accordion: AccordionComponent;
    constructor(accordion: AccordionComponent);
    ngOnInit(): void;
    ngOnDestroy(): void;
    toggleOpen(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AccordionPanelComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AccordionPanelComponent, "accordion-group, accordion-panel", never, { "heading": { "alias": "heading"; "required": false; "isSignal": true; }; "panelClass": { "alias": "panelClass"; "required": false; "isSignal": true; }; "isDisabled": { "alias": "isDisabled"; "required": false; "isSignal": true; }; "isOpenInput": { "alias": "isOpen"; "required": false; "isSignal": true; }; }, { "isOpenChange": "isOpenChange"; }, never, ["[accordion-heading]", "*"], true, never>;
}

declare class AccordionModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<AccordionModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<AccordionModule, never, [typeof AccordionComponent, typeof AccordionPanelComponent], [typeof AccordionComponent, typeof AccordionPanelComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<AccordionModule>;
}

export { AccordionComponent, AccordionConfig, AccordionModule, AccordionPanelComponent };
