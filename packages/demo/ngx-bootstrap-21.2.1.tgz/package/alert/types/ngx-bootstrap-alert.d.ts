import * as i0 from '@angular/core';
import { OnInit, ChangeDetectorRef } from '@angular/core';

declare class AlertConfig {
    /** default alert type */
    type: string;
    /** is alerts are dismissible by default */
    dismissible: boolean;
    /** default time before alert will dismiss */
    dismissOnTimeout?: number;
    static ɵfac: i0.ɵɵFactoryDeclaration<AlertConfig, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AlertConfig>;
}

declare class AlertComponent implements OnInit {
    private _config;
    private changeDetection;
    /** Alert type.
     * Provides one of four bootstrap supported contextual classes:
     * `success`, `info`, `warning` and `danger`
     */
    type: i0.InputSignal<string>;
    /** If set, displays an inline "Close" button */
    dismissible: i0.InputSignal<boolean>;
    /** Number in milliseconds, after which alert will be closed */
    dismissOnTimeout: i0.InputSignal<string | number | undefined>;
    /** Is alert visible */
    isOpen: i0.InputSignal<boolean>;
    /** This event fires immediately after close instance method is called,
     * $event is an instance of Alert component.
     */
    onClose: i0.OutputEmitterRef<AlertComponent>;
    /** This event fires when alert closed, $event is an instance of Alert component */
    onClosed: i0.OutputEmitterRef<AlertComponent>;
    classes: string;
    _isOpen: boolean;
    constructor(_config: AlertConfig, changeDetection: ChangeDetectorRef);
    ngOnInit(): void;
    /**
     * Closes an alert by removing it from the DOM.
     */
    close(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AlertComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AlertComponent, "alert,bs-alert", never, { "type": { "alias": "type"; "required": false; "isSignal": true; }; "dismissible": { "alias": "dismissible"; "required": false; "isSignal": true; }; "dismissOnTimeout": { "alias": "dismissOnTimeout"; "required": false; "isSignal": true; }; "isOpen": { "alias": "isOpen"; "required": false; "isSignal": true; }; }, { "onClose": "onClose"; "onClosed": "onClosed"; }, never, ["*"], true, never>;
}

declare class AlertModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<AlertModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<AlertModule, never, [typeof AlertComponent], [typeof AlertComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<AlertModule>;
}

export { AlertComponent, AlertConfig, AlertModule };
